import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw
from scipy.io import savemat

#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]



def rot2euler(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6
    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0
    return np.array([x, y, z])
#14\16\27
np.random.seed(30)
theta0=np.random.uniform(-1,1, (3,1))*(np.pi/4)
w0=np.random.uniform(-1,1, (3,1))* 0.05
x0=np.vstack((theta0.reshape(-1,1), w0))
print(x0)
steps=60
dt=0.1

Xcurrent=x0 #用来更新
x_ref=np.empty((steps+1,6))
x_ref[0, :] = Xcurrent.reshape(-1, )
#升高后维度为43
N_lift=len(getlift(x0))
x_ref_lift=np.empty((steps+1,N_lift)) #构建升维目标
x_ref_lift[0, :]=getlift(Xcurrent).reshape(-1,) #初值



## 多步误差
for i in range(steps):
    u = np.random.uniform(-1, 1, (3,))*0.5
    sn = odeint(dynamics, Xcurrent.reshape(-1, ), [0, dt], args=(u,))
    Xcurrent = sn[-1, :]
    x_ref[i+1, :] = Xcurrent.reshape(-1, )
    x_ref_lift[i+1, :]=(Alift@x_ref_lift[i, :]+Blift@(u))
# #可视化目标轨迹
# for i in range(6):
#     plt.plot(x_ref[:, i], label="x1", color='red')
#     plt.plot(x_ref_lift[:, i], label="x1", color='blue')
#     plt.show()

savemat('x_ref_lift.mat', {'x_ref_lift': x_ref_lift.T}) #保存到matlab
savemat('x_ref.mat', {'x_ref': x_ref.T}) #保存到matlab



