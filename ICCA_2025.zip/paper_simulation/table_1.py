import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw


#1 加载AB
# suffix = "6-27"
suffix = "9-3"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()



#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]
steps=50
tra=100 #轨迹
alpha=np.empty((tra,steps+1))
beta=np.empty((tra,steps+1))
omega=np.empty((tra,steps+1))
p=np.empty((tra,steps+1))
q=np.empty((tra,steps+1))
v=np.empty((tra,steps+1))

alpha_k=np.empty((tra,steps+1))
beta_k=np.empty((tra,steps+1))
omega_k=np.empty((tra,steps+1))
p_k=np.empty((tra,steps+1))
q_k=np.empty((tra,steps+1))
v_k=np.empty((tra,steps+1))
# np.random.seed(2)
dt=0.1
for i in range (tra):
    theta0 = np.random.uniform(-1, 1, (3, 1)) * (np.pi / 6)
    w0 = np.random.uniform(-1, 1, (3, 1)) * 0.05
    Xcurrent = np.vstack((theta0.reshape(-1, 1), w0))
    Xcurrent_k=getlift(Xcurrent).reshape(-1, )
    for j in range (steps):
        alpha[i,j]=Xcurrent[0]
        beta[i, j] = Xcurrent[1]
        omega[i, j] = Xcurrent[2]
        p[i, j] = Xcurrent[3]
        q[i, j] = Xcurrent[4]
        v[i, j] = Xcurrent[5]

        alpha_k[i,j]=Xcurrent_k[0]
        beta_k[i, j] = Xcurrent_k[1]
        omega_k[i, j] = Xcurrent_k[2]
        p_k[i, j] = Xcurrent_k[3]
        q_k[i, j] = Xcurrent_k[4]
        v_k[i, j] = Xcurrent_k[5]
        #u = np.random.uniform(-1, 1, (3,)) * 0.5
        u = np.random.uniform(-1, 1, (3,)) * 0.1
        sn = odeint(dynamics, Xcurrent.reshape(-1, ), [0, dt], args=(u,))
        Xcurrent = sn[-1, :]
        Xcurrent_k=(Alift@Xcurrent_k+Blift@(u))

sample=9
print(sample)
numerator = np.sum((alpha[:, sample] - alpha_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('alpha',RMSE)

numerator = np.sum((beta[:, sample] - beta_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('beta',RMSE)

numerator = np.sum((omega[:, sample] - omega_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('omega',RMSE)

numerator = np.sum((p[:, sample] - p_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('p',RMSE)

numerator = np.sum((q[:, sample] - q_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('q',RMSE)


numerator = np.sum((v[:, sample] - v_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('v',RMSE)

sample=29
print(sample)
numerator = np.sum((alpha[:, sample] - alpha_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('alpha',RMSE)

numerator = np.sum((beta[:, sample] - beta_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('beta',RMSE)

numerator = np.sum((omega[:, sample] - omega_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('omega',RMSE)

numerator = np.sum((p[:, sample] - p_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('p',RMSE)

numerator = np.sum((q[:, sample] - q_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('q',RMSE)


numerator = np.sum((v[:, sample] - v_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('v',RMSE)

sample=49
print(sample)
numerator = np.sum((alpha[:, sample] - alpha_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('alpha',RMSE)

numerator = np.sum((beta[:, sample] - beta_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('beta',RMSE)

numerator = np.sum((omega[:, sample] - omega_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('omega',RMSE)

numerator = np.sum((p[:, sample] - p_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('p',RMSE)

numerator = np.sum((q[:, sample] - q_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('q',RMSE)


numerator = np.sum((v[:, sample] - v_k[:, sample]) ** 2)
RMSE=np.sqrt(numerator/tra)
print('v',RMSE)