import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw


#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]



def rot2euler(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6
    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0
    return np.array([x, y, z])
#14\16\27
np.random.seed(30)
theta0=np.random.uniform(-1,1, (3,1))*(np.pi/4)
w0=np.random.uniform(-1,1, (3,1))* 0.05
x0=np.vstack((theta0.reshape(-1,1), w0))
print(x0)
steps=60
dt=0.1

Xcurrent=x0 #用来更新
x_ref=np.empty((steps+1,6))
x_ref[0, :] = Xcurrent.reshape(-1, )
#升高后维度为43
N_lift=len(getlift(x0))
x_ref_lift=np.empty((steps+1,N_lift)) #构建升维目标
x_ref_lift[0, :]=getlift(Xcurrent).reshape(-1,) #初值



## 多步误差
for i in range(steps):
    u = np.random.uniform(-1, 1, (3,))*0.5
    sn = odeint(dynamics, Xcurrent.reshape(-1, ), [0, dt], args=(u,))
    Xcurrent = sn[-1, :]
    x_ref[i+1, :] = Xcurrent.reshape(-1, )
    x_ref_lift[i+1, :]=(Alift@x_ref_lift[i, :]+Blift@(u))
# #可视化目标轨迹
# for i in range(6):
#     plt.plot(x_ref[:, i], label="x1", color='red')
#     plt.plot(x_ref_lift[:, i], label="x1", color='blue')
#     plt.show()





plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['text.usetex'] = True
fig, axes = plt.subplots(3, 2, figsize=(12, 8))
def plot_subfigure(ax, time, true_value, deep_edmd, ylabel):
    ax.plot(time, true_value,color='red',  linestyle='-',  linewidth=3,label='True value')
    ax.plot(time, deep_edmd, color='#1f77b4',  linestyle='--',  linewidth=3, label='Deep EDMD (Ours)')
    ax.set_xlabel('Time (s)',fontsize=20)
    ax.set_ylabel(ylabel,fontsize=20)
    # 调整刻度字体大小
    ax.tick_params(axis='both', labelsize=16)  # 主刻度字体
    ax.grid(True)

# Plotting each subplot

time=np.linspace(0, steps, steps+1)*0.1
plot_subfigure(axes[0, 0], time, x_ref[:, 0], x_ref_lift[:, 0],   r'$\alpha \, (rad)$')
plot_subfigure(axes[1, 0], time, x_ref[:, 1], x_ref_lift[:, 1],   r'$\beta \, (rad)$')
plot_subfigure(axes[2, 0], time, x_ref[:, 2], x_ref_lift[:, 2],  r'$\sigma \, (rad)$')
plot_subfigure(axes[0, 1], time, x_ref[:, 3], x_ref_lift[:, 3],   r'$p \, (rad/s)$')
plot_subfigure(axes[1, 1], time, x_ref[:, 4], x_ref_lift[:, 4],   r'$q \, (rad/s)$')
plot_subfigure(axes[2, 1], time, x_ref[:, 5], x_ref_lift[:, 5],   r'$v \, (rad/s)$')

plt.subplots_adjust(wspace=0.3,hspace = 0.6)
# Adding shared legend
fig.legend(framealpha=1,loc = 'lower center', bbox_to_anchor = (0.5, 0), prop = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }, ncol = 2, labels = ['True value', 'Deep koopman'])
plt.show()
# plt.savefig("exp1.svg", dpi=300,format="svg")
#plt.savefig('exp1_1120.eps', format='eps')










###ICGNC图片

# fig, axs  =  plt.subplots(3, 1, figsize = (12, 10), sharex = False,)
#
# for i in range(3):
#     # row, col  =  divmod(i, 2)
#     axs[i].plot(np.linspace(0, steps, steps+1), x_ref[:, i], label = f"Deep koopman ($q{i}$)", color = 'red',marker = ".")
#     axs[i].plot(np.linspace(0, steps, steps+1), x_ref_lift[:, i], label = f"True value ($q{i + 1}$)", color = 'blue',marker = "v",markersize=3)
#     if i==3:
#         axs[i].set_xlabel('Step', family = 'Times New Roman', fontsize = 20)
#     axs[i].set_ylabel(f"q$_{i + 1}$", family = 'Times New Roman', fontsize = 20, style = "italic")
#     axs[i].xaxis.set_visible(True)
#
#
# # 调整子图之间的间距
# plt.subplots_adjust(hspace = 0.4)
# # 在整体中下留白，避免与子图重叠
# fig.legend(framealpha=1,loc = 'lower center', bbox_to_anchor = (0.5, 0), prop = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }, ncol = 2, labels = ['Deep koopman', 'True value'])
# # 调整布局
# # plt.tight_layout(rect = [0, 1, 0, 1]) #左下右上 四个位置的偏移量 微调
#
# # 垂直留白
# plt.subplots_adjust(bottom = 0.15)
# # plt.savefig('q.eps', format='eps')
# plt.savefig("q.svg", dpi=300,format="svg")
# # 显示图形
# plt.show()




