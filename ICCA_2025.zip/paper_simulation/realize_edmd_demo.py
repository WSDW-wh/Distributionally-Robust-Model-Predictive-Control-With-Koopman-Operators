# cite  https://github.com/CTCingithub/KoopmanMPC-Igor2018/blob/main/Van_der_Pol.ipynb
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt


def VanderPol(STATE, t, INPUT):
    x1, x2 = STATE
    return [2 * x2, -0.8 * x1 + 2 * x2 - 10 * np.power(x1, 2) * x2 + INPUT]

#采集数据
dt = 0.05  # 采样间隔
N_state = 2  # 状态量个数
N_sim = 20  # 仿真时间
N_case = 10  # 轨迹个数

# 随机生成初始条件和输入
x_init_train = np.random.rand(N_state, N_case) * 2 - 1
u_snapshot_train = np.random.rand(1, N_sim * N_case) * 2 - 1
x_snapshot_train = np.zeros((N_state, N_case * (N_sim + 1)))

for i in range(N_case):
    # 导入初始条件
    x_snapshot_train[:, i * N_sim] = x_init_train[:, i]
    for j in range(N_sim):
        # 通过求解微分方程得到状态量数据，论文原代码使用龙格库塔法
        InitialCondition = x_snapshot_train[:, i * N_sim + j].tolist()
        snapshot_temp = odeint(
            VanderPol,
            InitialCondition,
            np.linspace(0, dt),
            args=(u_snapshot_train[:, i * N_sim + j],),
        ).T
        x_snapshot_train[:, i * N_sim + j + 1] = snapshot_temp[:, -1]

#定义矩阵X,Xprime
delete_list_1, delete_list_2 = [], [] #删除的，X删除最后一位，X^+删除第一位
for i in range(N_case):
    delete_list_1.append((i + 1) * N_sim - 1)
    delete_list_2.append(i * N_sim)

X = np.delete(x_snapshot_train, delete_list_1, axis=1)
Xprime = np.delete(x_snapshot_train, delete_list_2, axis=1)
Y = u_snapshot_train

#定义lifting function [x g(x)] ThinPlate
def RBF(x, x_center, epsilon=1, k=1, TYPE="ThinPlate"):
    RADIUS = np.linalg.norm(x - x_center)

    TYPE = TYPE.lower()
    if TYPE == "thinplate":
        return 0 if RADIUS == 0 else np.power(RADIUS, 2) * np.log(RADIUS)
    elif TYPE == "gauss":
        return np.exp(-np.power(epsilon * RADIUS, 2))
    elif TYPE == "invquad":
        return 1 / (1 + np.power(epsilon * RADIUS, 2))
    elif TYPE == "invmultquad":
        return 1 / np.sqrt(1 + np.power(epsilon * RADIUS, 2))
    elif TYPE == "polyharmonic":
        return np.power(RADIUS, k) * np.log(RADIUS)

def LiftFun(x, x_center, Type="thinplate", Epsilon=1, K=1, WithOriginalState=True):
    if len(x.shape) == 1:
        x = x.reshape(-1, 1)
    x_rbf = np.zeros((len(x_center), x.shape[1]))

    for column in range(x_rbf.shape[1]):
        for row in range(len(x_center)):
            x_rbf[row, column] = RBF(
                x[:, column].reshape(-1, 1),
                x_center[row],
                epsilon=Epsilon,
                k=K,
                TYPE=Type,
            )
    if WithOriginalState:
        return np.concatenate((x, x_rbf), axis=0)
    else:
        return x_rbf.reshape(-1, x.shape[1])

#使用 lifting function
N_RBFcenters = 100
centers = np.random.rand(N_state, N_RBFcenters) * 2 - 1
centers_tuple = [centers[:, i] for i in range(centers.shape[1])]
centers_tuple = tuple(centers_tuple)

Z = LiftFun(X, centers_tuple, Type="thinplate", WithOriginalState=True)
Zprime = LiftFun(Xprime, centers_tuple, Type="thinplate", WithOriginalState=True)


#求解A,B
def DMDc_Milan(Z, Zprime, Y, X):
    W_left, W_right = (
        np.concatenate((Zprime, X), axis=0) @ np.concatenate((Z, Y), axis=0).conj().T,
        np.concatenate((Z, Y), axis=0) @ np.concatenate((Z, Y), axis=0).conj().T,
    )

    A_B_C_0 = W_left @ np.linalg.pinv(W_right)

    A = A_B_C_0[: Zprime.shape[0], : Z.shape[0]]
    B = A_B_C_0[: Zprime.shape[0], Z.shape[0] :]
    C = A_B_C_0[Zprime.shape[0] :, : Z.shape[0]]
    # 看右下角是不是全0，直接对右下角所有元素的平方求和
    error = np.sum(np.power(A_B_C_0[Zprime.shape[0] :, Z.shape[0] :], 2))

    return A, B, C, error

A_Milan, B_Milan, C_Milan = (
    DMDc_Milan(Z, Zprime, Y, X)[0],
    DMDc_Milan(Z, Zprime, Y, X)[1],
    DMDc_Milan(Z, Zprime, Y, X)[2],
)
#验证代理模型精度
N_sim_test = 50
x_init_test = np.random.rand(N_state, 1) * 2 - 1
u_snapshot_test = np.random.rand(1, N_sim_test) * 2 - 1

#真实
x_snapshot_test_true = np.zeros((N_state, N_sim_test + 1))
x_snapshot_test_true[:, 0] = x_init_test.reshape(
    -1,
)
#代理
x_snapshot_test_DMDc_Milan = np.zeros((N_state, N_sim_test + 1))
x_snapshot_test_DMDc_Milan[:, 0] = x_init_test.reshape(
    -1,
)

for j in range(N_sim_test):
    # 通过求解微分方程得到状态量数据，论文原代码使用龙格库塔法
    InitialCondition = x_snapshot_test_true[:, j].tolist()
    snapshot_temp = odeint(
        VanderPol,
        InitialCondition,
        np.linspace(0, dt),
        args=(u_snapshot_test[:, j],),
    ).T
    x_snapshot_test_true[:, j + 1] = snapshot_temp[:, -1]

for j in range(N_sim_test):
    z_temp_DMD_Milan = LiftFun(
        x_snapshot_test_DMDc_Milan[:, j],
        centers_tuple,
        Type="thinplate",
    )

    zprime_temp_DMD_Milan = A_Milan @ z_temp_DMD_Milan + (
        B_Milan @ u_snapshot_test[:, j]
    ).reshape(N_state + N_RBFcenters, 1)

    x_Milan_temp = C_Milan @ zprime_temp_DMD_Milan
    x_snapshot_test_DMDc_Milan[:, j + 1] = x_Milan_temp[:, -1]

plt.plot(np.linspace(0, N_sim_test * dt, N_sim_test + 1), x_snapshot_test_true[0, :])
plt.scatter(
    np.linspace(0, N_sim_test * dt, N_sim_test + 1),
    x_snapshot_test_DMDc_Milan[0, :],
    marker="x",
    c="g",
)
plt.title("Milan论文DMDc近似结果", fontsize=25)
plt.xlabel("$t$", fontsize=13, x=1)
plt.ylabel("$x$", fontsize=13, y=1, rotation=1)
plt.show()