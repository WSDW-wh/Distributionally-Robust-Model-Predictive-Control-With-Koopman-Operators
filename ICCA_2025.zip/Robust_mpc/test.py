import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
from cvxpy import *
from utils import *
import os
import train as lkw


#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    # 无噪声
    # wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))
    #有噪声
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1)+np.random.uniform(-1, 1, (3, 1)) * (0.001))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]

#3 定义MPC框架
#z0，zr，A,B,wr，N
def MPCcost(z_init,zr,A_bar,B_bar,w_r,N,Q,R,Q_N,x_min, x_max, u_min, u_max):
    u = Variable((3, N))
    x = Variable((len(z_init), N + 1))
    objective = 0
    constraints = [x[:, 0] == z_init]
    for i in range(N):
        constraints += [x[:, i + 1] == A_bar @ x[:, i] + B_bar @ (u[:,i])+w_r]
        constraints += [x_min <= x[3:6, i+1], x[3:6, i+1] <= x_max]  # 状态约束
        constraints += [u_min <= u[:, i], u[:, i] <= u_max]  # 控制约束
        objective += quad_form(x[:,i] - zr, Q) + quad_form(u[:,i], R)
    objective += quad_form(x[:,N] - zr, Q_N)
    # constraints += [x_min <= x[:, N], x[:, N] <= x_max]  # 最终状态约束
    prob = Problem(Minimize(objective), constraints)
    prob.solve()
    u_m = u[:,0].value
    return u_m
