import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw

#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

nq=len(Alift)
Q=np.zeros((nq,nq))

Q[:6,:6]=np.eye(6)*1000#q的权重
R=np.eye(3)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)

print(k.shape)
AK=Alift-Blift@k
print(AK.shape)

W=np.load('W.npy')
Z_s=W

# Define the number of iterations
iterations = 3
tolerance = 1e-3

for i in range(iterations):
    # Compute the next Z_s: Z_s_new = F * Z_s + W
    Z_s_new = abs(AK @ Z_s) + W

    # Check for convergence
    if np.allclose(Z_s_new, Z_s, atol=tolerance):
        print(f"Converged after {i + 1} iterations.")
        break

    Z_s = Z_s_new

np.save('Z_s.npy',Z_s)
print(Z_s)
print(k@Z_s)