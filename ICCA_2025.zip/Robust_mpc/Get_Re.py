import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw
from scipy.spatial import ConvexHull

#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()


def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]

steps=200
dt=0.1

# 随机状态
W=np.random.rand(NKoopman, 1)*0
a0=0
b0=0
c0=0
for i in range(100):
    q0 = np.random.uniform(-1, 1, (3,)) * (np.pi / 4)
    wb0 = np.random.uniform(-1, 1, (3,)) * 0.1
    x0 = np.vstack((q0.reshape(-1, 1), wb0.reshape(-1, 1))).reshape(-1, )
    # 随机控制量
    u10 = np.random.uniform(-1, 1, (3,)) * 0.5


    X_true = odeint(dynamics, x0, [0, dt], args=(u10,))[-1, :]
    X_true_koopman=getlift(X_true)
    X_Koopman = (Alift @ (getlift(x0)).reshape(-1, ) + Blift @ (u10))
    new_w=abs(X_Koopman.reshape(-1,1)-X_true_koopman.reshape(-1,1))
    W = np.where(new_w > W, new_w, W)
# np.save('W.npy',W)
print(W)

nq=len(Alift)
Q=np.zeros((nq,nq))

Q[:6,:6]=np.eye(6)*1000#q的权重
R=np.eye(3)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)
AK=Alift-Blift@k
print(AK.shape)

# Initialize the reachable set as the empty set
reachable_set = W # Empty set with correct dimensions


i=7
Re=np.zeros((3,i))
# Calculate the reachable set R_i^e
for j in range(1,i+1):
    A_power_j = np.linalg.matrix_power(AK, j)
    transformed_set =  0.5*A_power_j@W# Transform the disturbance set
    reachable_set = reachable_set+abs(transformed_set)
    Re[:,j-1]=reachable_set[3:6,:].reshape(-1,)
np.save('Re.npy',Re)
