import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
import os
import train as lkw
from scipy.spatial import ConvexHull
from scipy.linalg import solve_discrete_are
import scipy.linalg as la
#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()


def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]

steps=200
dt=0.1


nq=len(Alift)
Q=np.zeros((nq,nq))

Q[:6,:6]=np.eye(6)*1000#q的权重
R=np.eye(3)
Alift=np.matrix(Alift)
Blift=np.matrix(Blift)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)

def solve_dare(A, B, Q, R):
    """
    solve a discrete time_Algebraic Riccati equation (DARE)
    """
    x = Q
    x_next = Q
    max_iter = 150
    eps = 0.01
    for i in range(max_iter):
        x_next = A.T @ x @ A - A.T @ x @ B @ \
 \
                 la.inv(R + B.T @ x @ B) @ B.T @ x @ A + Q

        if (abs(x_next - x)).max() < eps:
            break
        x = x_next
    return x_next

P = solve_dare(Alift, Blift, Q, R)
print(P.shape)
