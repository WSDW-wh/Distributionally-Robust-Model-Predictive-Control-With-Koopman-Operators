import torch
import numpy as np
import matplotlib.pyplot as plt
import random
import sys
import os
from data import data_collecter

os.environ['KMP_DUPLICATE_LIB_OK'] = "TRUE"

def eval_err(suffix,env_name):
    method = 'KoopmanU'
    root_path = "./Data/" + suffix
    if method.endswith("KoopmanU"):
        import train as lka
    for file in os.listdir(root_path):
        if file.startswith(method+"_"+env_name) and file.endswith(".pth"):
            model_path = file
    Data_collect = data_collecter(env_name)
    udim = Data_collect.udim
    Nstates = Data_collect.Nstates

    dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))

    state_dict = dicts["model"]
    if method.endswith("KoopmanU"):
        layer = dicts["layer"]
        NKoopman = layer[-1]+Nstates
        net = lka.Network(layer,NKoopman,udim)
    net.load_state_dict(state_dict)
    # device = torch.device("cuda:0")
    net.cuda()
    net.double()
    steps = 100 #30
    with torch.no_grad():
        test_data = Data_collect.collect_koopman_data(1, steps)
        Turedata = test_data.reshape(steps+1, Nstates+udim).T
        koopmandata = np.zeros((Nstates, steps + 1))
        koopmandata[:, 0] = test_data[0, 0, udim:]

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        data = torch.DoubleTensor(test_data).to(device)
        X_current = net.encode(data[0, :, udim:])
        if method.endswith("KoopmanU"):
            for i in range(steps):
                X_current = net.forward(X_current, data[i, :, :udim])
                koopmandata[:, i + 1] = X_current[0, :Nstates].cpu()
    return koopmandata,Turedata,steps,Nstates,udim,data[:, :, :udim]

suffix = "6-27"
env_names = ["Spacecraft_theta"]
for env_name in env_names:
    koopmandata,Turedata,steps,Nstates,udim,control=eval_err(suffix,env_name)

control=control.reshape(-1,1).cpu()
for i in range(Nstates):
    plt.plot(np.linspace(0, steps, steps + 1), Turedata[i+udim, :], label="Ture", )
    plt.scatter(
        np.linspace(0, steps, steps + 1),
        koopmandata[i, :],
        marker="x",
        c="g",
        label="koopman",
    )
    plt.legend(loc='lower left')
    plt.title("True_and_koopman", fontsize=15)
    plt.xlabel("$t$", fontsize=13, x=1)
    plt.ylabel("$x$", fontsize=13, y=1, rotation=1)
    plt.show()
