import numpy as np

# 假设 sim_step = 100, 46 状态
sim_step = 100
num_states = 46

# 生成一个 sim_step x 46 的随机数据
chazhi = np.random.rand(sim_step, num_states)

# 计算每个状态的均值
mean_values = np.mean(chazhi, axis=0)  # 对每列计算均值

# 计算协方差矩阵
cov_matrix = np.cov(chazhi, rowvar=False)  # rowvar=False 表示每列是一个变量

# 输出结果
# 创建一个 2x2 矩阵
A = np.array([[1, 2],
              [3, 4]])

# 计算矩阵的 3 次幂
A_power_3 = np.linalg.matrix_power(A, 3)

print("矩阵 A 的 3 次幂：\n", np.linalg.matrix_power(A, 0))