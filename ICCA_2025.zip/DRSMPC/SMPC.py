import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from fontTools.varLib.mutator import percents

from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
from cvxpy import *
from utils import *
import os
import train as lkw
from scipy.linalg import sqrtm
from scipy.io import savemat


#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    # 无噪声
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))
    #有噪声
    # wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1)+np.random.uniform(-1, 1, (3, 1)) * (0.001))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]


#3 定义MPC框架
#假装均值和协方差
means=np.load('means.npy')
cov_matrix=np.load('cov_matrix.npy')
sqrt_cov_matrix = sqrtm(cov_matrix)
w_r=np.load('w_r.npy')
#3.1 z0 与 \mu
theta_0= np.random.uniform(-1, 1, (3,)) * 0
w_0= np.random.uniform(-1, 1, (3,)) * 0
x_0 = np.vstack((theta_0.reshape(-1, 1), w_0.reshape(-1, 1))).reshape(-1, )
z0 = getlift(x_0).reshape(-1, )
mu=means-w_r
#3.2
epxiong = 0.2
sqrt_result = np.sqrt((1-epxiong)/epxiong)

def MPCcost(z_init,zr,A_bar,B_bar,w_r,N,Q,R,k,P_c, x_max, u_min, u_max):
    A_K=(A_bar-B_bar@k)
    u = Variable((3, N))
    c= Variable((3, N))
    x = Variable((len(z_init), N + 1))
    objective = 0
    constraints = [x[:, 0] == z_init]
    a_1=0
    c_1=0
    for i in range(N-1):
        constraints += [x[:, i + 1] == A_bar @ x[:, i] + B_bar @ (u[:,i])+mu]
        constraints += [u[:, i] == -(k@(x[:, i]))+c[:,i]]
        if i==0:
            constraints += [u_min <= u[:, i], u[:, i] <= u_max]  # 控制约束
            constraints += [-(x_max) <= x[3:6, i], x[3:6, i] <= x_max ]  # 状态约束
        if i>0:
            a_1=a_1+np.linalg.matrix_power(A_K, i-1)
            a_2=a_1@sqrt_cov_matrix
            norm_a_k = np.linalg.norm(a_2)
            norm_a_k=sqrt_result*norm_a_k
            norm_a_k = np.asarray([norm_a_k, norm_a_k, norm_a_k])
            constraints += [-(x_max - norm_a_k) <= x[3:6, i], x[3:6, i] <= x_max - norm_a_k]  # 状态约束

            c_1 = c_1 +k@ np.linalg.matrix_power(A_K, i-1)
            c_2=c_1@sqrt_cov_matrix
            norm_c_k = np.linalg.norm(c_2)
            norm_c_k=sqrt_result*norm_c_k*0
            print('c',i,norm_c_k)
            norm_c_k = np.asarray([norm_c_k, norm_c_k, norm_c_k])
            constraints += [-(u_max-norm_c_k) <= u[:, i], u[:, i]  <= u_max-norm_c_k]  # 状态约束

        objective += quad_form(x[:,i], Q)+quad_form(u[:,i], R)
    # constraints += [x_min <= x[:, N], x[:, N] <= x_max]  # 最终状态约束
    prob = Problem(Minimize(objective), constraints)
    prob.solve()
    u_m = u[:,0].value
    return u_m


#4 仿真 初始姿态与目标姿态 x0与xd
R_0=np.array([[0.4830, 0.8365,  0.2588],
                [-0.3209, 0.4441, -0.8365],
                [-0.8147, 0.3209, 0.4830]])

R_d=np.array([[1, 0,  1],
                [0, 1, 0],
                [0, 0, 1]])

np.random.seed(5)
theta_0=rot2euler(R_0)*np.pi/180
theta_d=rot2euler(R_d)
theta_d[0]=0.9
w_0= np.random.uniform(-1, 1, (3,)) * 0
w_d= np.random.uniform(-1, 1, (3,)) * 0
x_0 = np.vstack((theta_0.reshape(-1, 1), w_0.reshape(-1, 1))).reshape(-1, )
x_d = np.vstack((theta_d.reshape(-1, 1), w_d.reshape(-1, 1))).reshape(-1, )

#5状态方程, 升维后的状态
Alift=Alift
Blift=Blift
z_0=getlift(x_0)
z_d=getlift(x_d)

#定义Q,R,k
nq=len(Alift)
Q=np.zeros((nq,nq))
Q[:6,:6]=np.eye(6)*1000#q的权重
R=np.eye(3)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)
P=solve_dare(Alift, Blift, Q, R)
P_c=R+Blift.T@P@Blift

nsim=300
N=7
dt=0.1
Xcurrent=x_0
Turedata = np.zeros((6, nsim + 1))
Turedata[:, 0] = Xcurrent.reshape(-1, )
Controldata = np.zeros((3, nsim))
z_k=z_0
z=z_0
u_max=np.asarray([0.5,0.5,0.5])
u_min=-1*u_max
distru=0.0005
x_max=np.asarray([0.2,0.2,0.2])
x_min=-1*x_max
for i in range(nsim):
    print(i)
    u_m=MPCcost(z_0.reshape(-1,),z_d.reshape(-1,),Alift,Blift,w_r.reshape(-1,),N,Q,R,k,P_c, x_max, u_min, u_max)
    Controldata[:, i]= u_m.reshape(-1, )
    sn = odeint(dynamics, Xcurrent, [0, dt], args=(u_m,))
    Xcurrent = sn[-1, :]+np.random.uniform(-1, 1, (6, )) * (distru)
    Turedata[:, i + 1] = Xcurrent.reshape(-1, )
    z_0 = getlift(Xcurrent)-getlift(x_d)

for i in range(6):
    plt.plot(Turedata[i, :], color='blue')
    plt.axhline(x_d[i],color='red')
    plt.axhline(0.2,color='red')
    plt.axhline(-0.2, color='red')
    plt.show()

for i in range(3):
    plt.plot(Controldata[i, :], color='blue')
    plt.axhline(0,color='red')
    plt.axhline(0, color='red')
    plt.show()

Xcurrent=x_0
z_0=getlift(x_0)
LQRdata = np.zeros((6, nsim + 1))
LQRdata[:, 0] = Xcurrent.reshape(-1, )
LQRControldata = np.zeros((3, nsim))
for i in range(nsim):
    print(i)
    u_m=-np.array(k@(z_0-z_d)).reshape(-1, )
    u_m=np.clip(u_m, -0.5, 0.5)
    LQRControldata[:, i]= u_m.reshape(-1, )
    sn = odeint(dynamics, Xcurrent, [0, dt], args=(u_m,))
    Xcurrent = sn[-1, :]+np.random.uniform(-1, 1, (6, )) * (distru)
    LQRdata[:, i + 1] = Xcurrent.reshape(-1, )
    z_0 = getlift(Xcurrent)




plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['text.usetex'] = True
fig, axes = plt.subplots(3, 1, figsize=(12, 8))
linewidth=2
def plot_subfigure(ax, time, true_value, deep_edmd, ylabel):
    ax.plot(time, true_value,color='red',  linestyle='-',  linewidth=linewidth,label='True value')
    ax.plot(time, deep_edmd, color='#1f77b4',  linestyle='--',  linewidth=linewidth, label='Deep EDMD (Ours)')
    ax.set_xlabel('Time (s)',fontsize=20)
    ax.set_ylabel(ylabel,fontsize=20)
    # 调整刻度字体大小
    ax.tick_params(axis='both', labelsize=16)  # 主刻度字体
    ax.grid(True)

# Plotting each subplot
# jiaodu
time=np.linspace(0, nsim, nsim+1)*0.1
plot_subfigure(axes[0], time, Turedata[0, :], LQRdata[0, :],   r'$\alpha \, (rad)$')
plot_subfigure(axes[1], time, Turedata[1, :], LQRdata[1, :],   r'$\beta \, (rad)$')
plot_subfigure(axes[2], time, Turedata[2, :], LQRdata[2, :],  r'$\sigma \, (rad)$')
plt.subplots_adjust(hspace = 0.4)
# Adding shared legend
fig.legend(framealpha=1,loc = 'lower center', bbox_to_anchor = (0.5, 0), prop = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }, ncol = 2, labels = ['MPC', 'LQR'])
plt.show()
# plt.savefig('q.eps', format='eps')

# jiaosudu
fig, axes = plt.subplots(3, 1, figsize=(12, 8))
w_max=0.2
plot_subfigure(axes[0], time, Turedata[3, :], LQRdata[3, :],   r'$p \, (rad/s)$')
axes[0].axhline(y=w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={w_max}')
axes[0].axhline(y=-w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-w_max}')
plot_subfigure(axes[1], time, Turedata[4, :], LQRdata[4, :],  r'$q \, (rad/s)$')
axes[1].axhline(y=w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={w_max}')
axes[1].axhline(y=-w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-w_max}')
plot_subfigure(axes[2], time, Turedata[5, :], LQRdata[5, :],  r'$v \, (rad/s)$')
axes[2].axhline(y=w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={w_max}')
axes[2].axhline(y=-w_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-w_max}')
plt.subplots_adjust(hspace = 0.4)
# Adding shared legend
fig.legend(framealpha=1,loc = 'lower center', bbox_to_anchor = (0.5, 0), prop = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }, ncol = 2, labels = ['MPC', 'LQR'])
plt.show()
# plt.savefig('w_1120.eps', format='eps')

# control
fig, axes = plt.subplots(3, 1, figsize=(12, 8))
u_max=0.5
time=np.linspace(0, nsim, nsim)*0.1
plot_subfigure(axes[0], time, Controldata[0, :], LQRControldata[0, :],   r'$\tau_{1} \, (Nm)$')
axes[0].axhline(y=u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={u_max}')
axes[0].axhline(y=-u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-u_max}')
plot_subfigure(axes[1], time, Controldata[1, :], LQRControldata[1, :],  r'$\tau_{2} \, (Nm)$')
axes[1].axhline(y=u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={u_max}')
axes[1].axhline(y=-u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-u_max}')
plot_subfigure(axes[2], time, Controldata[2, :], LQRControldata[2, :],  r'$\tau_{3} \, (Nm)$')
axes[2].axhline(y=u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={u_max}')
axes[2].axhline(y=-u_max, color='green', linestyle='-.', linewidth=linewidth, label=f'Horizontal line at y={-u_max}')
plt.subplots_adjust(hspace = 0.4)
# Adding shared legend
fig.legend(framealpha=1,loc = 'lower center', bbox_to_anchor = (0.5, 0), prop = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20, }, ncol = 2, labels = ['MPC', 'LQR'])
plt.show()
# plt.savefig('u_1120.eps', format='eps')
