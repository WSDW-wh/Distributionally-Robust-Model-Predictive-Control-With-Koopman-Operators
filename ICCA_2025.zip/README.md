# ICCA 2025 Spacecraft Attitude Control Experiments

This repository contains the simulation and experiment code for spacecraft attitude control with Koopman-based modeling, robust MPC, stochastic MPC, and paper-figure reproduction scripts.

The code is kept close to the original experiment implementation. Most scripts are research scripts with hard-coded experiment settings and relative paths.

## Repository Layout

```text
.
├── train.py                  # Train the Koopman neural model
├── eval.py                   # Evaluate and plot Koopman prediction results
├── data.py                   # Spacecraft attitude simulation environment and data collection
├── utils.py                  # Shared dynamics, LQR, and matrix utilities
├── DRSMPC/                   # Distributionally robust / stochastic MPC scripts
├── Robust_mpc/               # Robust MPC scripts and invariant-set utilities
├── paper_simulation/         # Scripts for reproducing paper simulations, plots, and tables
├── exper/                    # Additional exploratory experiment scripts
├── matlab保存/               # MATLAB export / saved-data helper scripts
└── Data/                     # Generated datasets, checkpoints, and logs
```

## Installation

Python 3.8+ is recommended. Create a virtual environment first:

```bash
python -m venv .venv
```

On Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

On Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
```

Install the PyTorch build that matches your CUDA version if GPU acceleration is needed. See the official PyTorch installation page for platform-specific commands.

## Typical Workflow

Generate/load data and train the Koopman model:

```bash
python train.py --env Spacecraft_theta --suffix 6-27 --K_train_samples 50000 --encode_dim 40 --layer_depth 3 --gamma 0.99
```

Evaluate the trained model:

```bash
python eval.py
```

Run MPC and paper simulation scripts from the repository root so relative imports and paths resolve correctly, for example:

```bash
python DRSMPC/ICCA.py
python Robust_mpc/Rmpc_control.py
python paper_simulation/plot_control.py
```

## Data and Outputs

Large/generated files are intentionally ignored by Git:

- `Data/` datasets, checkpoints, and TensorBoard logs
- `*.pth`, `*.pt`
- `*.npy`, `*.npz`
- `*.mat`
- generated `*.eps` figures

The current scripts use relative paths such as `./Data/dataset/train` and `./Data/dataset/test`. Empty placeholder files are kept so these directories exist in a fresh clone.

## Notes

- Run scripts from the repository root.
- Some evaluation/control scripts expect a trained model checkpoint under `Data/<suffix>/`.
- Several scripts are intended for reproducing specific experiments and may contain fixed constants from the paper experiments.
- `KMP_DUPLICATE_LIB_OK` is set inside some scripts to avoid local OpenMP runtime conflicts on Windows.

