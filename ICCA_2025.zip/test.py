import matplotlib.pyplot as plt
import numpy as np
import torch
import sys
print(torch.__version__)
print(sys.version)