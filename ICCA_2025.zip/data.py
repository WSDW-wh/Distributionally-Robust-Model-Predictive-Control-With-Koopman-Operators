import numpy as np
import gym
from scipy.integrate import odeint
from utils import matrixtoquaternion
import scipy.linalg
from copy import copy
from gym import spaces
import sys

##


class Spacecraft_theta():
    def __init__(self) -> None:
        self.I = np.diag([3, 4, 5])
        # self.I=np.asarray([[59.22, -1.14, -0.8], [-1.14, 40.56, 0.10], [-0.80, 0.10, 57.60]])
        self.dt = 0.1
        self.Nstates = 6

    def reset(self):
        # x_init_train = np.random.rand(6, 1) * 2 - 1
        # x_init_train[0:4]= x_init_train[0:4] / np.linalg.norm( x_init_train[0:4])
        # s0 = x_init_train.reshape(-1, )
        q0=np.random.uniform(-1,1, (3,))*(np.pi/4)
        wb0= np.random.uniform(-1, 1, (3,)) * 0.1
        s0=np.vstack((q0.reshape(-1, 1), wb0.reshape(-1,1 ))).reshape(-1,)
        self.s0=s0
        return self.s0

    def reset_state(self, s):
        self.s0 = s
        return self.s0
    def hat(self,x):
        xhat = np.asarray([[0, -x[2].item(), x[1].item()], [x[2].item(), 0, -x[0].item()], [-x[1].item(), x[0].item(), 0]])
        return xhat

    def dynamics(self,y, t, INPUT):
        I = np.diag([3, 4, 5])
        theta = y[0:3].reshape(-1, 1)
        afa = theta[0].item()
        beta = theta[1].item()
        R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                        [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
        w = y[3:].reshape(-1, 1)
        thetadot = R @ w
        inv_I = np.linalg.inv(I)
        wdot = np.dot(inv_I, -self.hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

        # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
        return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
                wdot[2].item()]

    def step(self, u):
        u = np.array(u).reshape(-1)
        sn = odeint(self.dynamics, self.s0, [0, self.dt], args=(u,))
        self.s0 = sn[-1, :]
        r = 0
        done = False
        return self.s0, r, done, {}



class data_collecter():
    def __init__(self,env_name) -> None:
        self.env_name = env_name
        self.env = Spacecraft_theta()
        self.Nstates = self.env.Nstates
        self.udim = 3
        self.env.reset()
        self.dt = self.env.dt


    def collect_koopman_data(self,traj_num,steps,mode="train"):
        train_data = np.empty((steps+1,traj_num,self.Nstates+self.udim))
        for traj_i in range(traj_num):
            s0 = self.env.reset()
            u10 = np.random.uniform(-1,1, (3,))*0.5
            train_data[0,traj_i,:]=np.concatenate([u10.reshape(-1),s0.reshape(-1)],axis=0).reshape(-1)
            for i in range(1,steps+1):
                s0,r,done,_ = self.env.step(u10)
                u10 = np.random.uniform(-1,1, (3,))*0.5
                train_data[i,traj_i,:]=np.concatenate([u10.reshape(-1),s0.reshape(-1)],axis=0).reshape(-1)
        return train_data
