import numpy as np
import math
def rot2euler(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

    singular = sy < 1e-6

    if not singular:
        x = math.atan2(R[2, 1], R[2, 2]) * 180 / np.pi
        y = math.atan2(-R[2, 0], sy) * 180 / np.pi
        z = math.atan2(R[1, 0], R[0, 0]) * 180 / np.pi
    else:
        x = math.atan2(-R[1, 2], R[1, 1]) * 180 / np.pi
        y = math.atan2(-R[2, 0], sy) * 180 / np.pi
        z = 0

    return np.array([x, y, z])


rot = np.array([[0.4830, 0.8365,  0.2588],
                [-0.3209, 0.4441, -0.8365],
                [-0.8147, 0.3209, 0.4830]])

rot = np.array([[1, 0,  1],
                [0, 1, 0],
                [0, 0, 1]])

print(rot2euler(rot))

for i in range(3):
    print(i)
