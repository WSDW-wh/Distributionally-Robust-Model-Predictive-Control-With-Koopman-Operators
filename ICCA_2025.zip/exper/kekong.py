import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
from cvxpy import *
from utils import *
import os
import train as lkw

#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()


def kekong(A,B):
    AB={}
    AB[0]=B
    for i in range(1,A.shape[0]):
        AB[i]=A.dot(AB[i-1])
    q=np.column_stack((AB.values()))
    print("系数矩阵为:",q)
    #保证非奇异性
    z=q.dot(q.T)
    print(z)
    if np.linalg.det(z)!=0:
        print("非奇异矩阵，行列式为：",np.linalg.det(z))
    else:
        print( "奇异矩阵行列式为：",np.linalg.det(z))
    print("矩阵的秩为",np.linalg.matrix_rank(q))
    if np.linalg.matrix_rank(z)!=A.shape[0]:
        print("矩阵不可控")
    else:
        print("矩阵可控")
    return np.linalg.matrix_rank(z)
#
# kekong(Alift,Blift)


def check_stability(A, B, K):
    closed_loop_matrix = A + B @ K
    eigenvalues = np.linalg.eigvals(closed_loop_matrix)
    is_stable = np.all(np.abs(eigenvalues) < 1)
    return is_stable, eigenvalues

nq=len(Alift)
Q=np.zeros((nq,nq))

Q[:6,:6]=np.eye(6)*100#q的权重
R=np.eye(3)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)
is_stable, eigenvalues=check_stability(Alift, Blift, -k)
print(is_stable)