import numpy as np
from scipy.integrate import odeint
from utils import hat
import matplotlib.pyplot as plt
import math



def rot2euler(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6
    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0
    return np.array([x, y, z])


def dynamics(STATE, t, INPUT):
    I=np.diag([3,4,5])
    theta=STATE[0:3].reshape(-1,1)
    afa=theta[0].item()
    beta = theta[1].item()
    R=np.asarray([[-np.tan(beta)*np.cos(afa), 1,-np.tan(beta)*np.sin(afa) ], [np.sin(afa), 0, -np.cos(afa)],[-np.cos(beta)*np.cos(afa), -np.sin(beta),-np.cos(beta)*np.sin(afa)]])
    w=STATE[3:].reshape(-1,1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w)+INPUT.reshape(-1,1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(),wdot[0].item(),wdot[1].item(),wdot[2].item()]

R0=np.asarray([[0.8481, -0.0140,  0.5296],
               [0.4606,  0.5132, -0.7242],
               [-0.2616, 0.8581, 0.4417]])
theta0=rot2euler(R0)
Rd=np.eye(3)
thetad=rot2euler(Rd)

steps=1000
x_state=np.empty((6,steps))
x_tau=np.empty((6,steps))
dt=0.1
wd=np.asarray([[np.sin(0.2 * 0*dt)],[np.sin(0.3 * 0*dt)],[np.cos(0.2 * 0*dt)]])*0.1
xd=np.vstack((thetad.reshape(-1,1), wd))
Xcurrent=xd #用来更新
X_tau=xd
u=np.asarray([[0],[0],[0]])
print(Xcurrent)
J=np.diag([3, 4, 5])
# for i in range(steps):
#     #以w更新
#     wd=np.asarray([[np.sin(0.2 * i*dt)],[np.sin(0.3 * i*dt)],[np.cos(0.2 * i*dt)]])*0.1
#     Xcurrent=np.vstack((Xcurrent[:3], wd))
#     x_state[:,i]=Xcurrent.reshape(-1,)
#     sn = odeint(dynamics, Xcurrent.reshape(-1, ), [0, dt], args=(u,))
#     Xcurrent = sn[-1, :].reshape(-1, 1)
#
#     # 以tau更新
#     w_dot=np.asarray([[0.2*np.cos(0.2 * i*dt)],[0.3*np.cos(0.3 * i*dt)],[-0.2*np.sin(0.2 * i*dt)]])*0.1
#     tau=J@w_dot+hat(wd)@J@wd
#     x_tau[:, i] = X_tau.reshape(-1, )
#     sn = odeint(dynamics, X_tau.reshape(-1, ), [0, dt], args=(tau,))
#     X_tau=sn[-1, :]

# #可视化目标轨迹
# for i in range(6):
#     plt.plot(x_state[i, :], label="x1", color='red')
#     plt.plot(x_tau[i, :], label="x2", color='blue')
#     plt.show()

# 通过输出可以看到，不是以w更新和以tau更新是不一样的，所以默认用tau更新
#轨迹生成用以下代替
Rd=np.eye(3)
thetad=rot2euler(Rd)
steps=600
x_state=np.empty((6,steps))
dt=0.1
Xcurrent=xd #用来更新

for i in range(steps):
    # 以tau更新
    w_dot=np.asarray([[0.2*np.cos(0.2 * i*dt)],[0.3*np.cos(0.3 * i*dt)],[-0.2*np.sin(0.2 * i*dt)]])*0.1
    tau=J@w_dot+hat(wd)@J@wd
    x_state[:, i] = Xcurrent.reshape(-1, )
    sn = odeint(dynamics, Xcurrent.reshape(-1, ), [0, dt], args=(tau,))
    Xcurrent=sn[-1, :]

for i in range(6):
    plt.plot(x_state[i, :], label="x1", color='red')
    plt.show()