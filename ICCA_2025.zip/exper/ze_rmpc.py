import torch
import numpy as np
import math
import matplotlib.pyplot as plt
from utils import matrixtoquaternion
from utils import dlqr,dm_to_array,hat
from scipy.integrate import odeint
from cvxpy import *
from utils import *
import os
import train as lkw

#1 加载AB
suffix = "6-27"
method = 'KoopmanU'
root_path = "../Data/" + suffix
env_names = "Spacecraft_theta"
root_path = "../Data/" + suffix
for file in os.listdir(root_path):
    if file.startswith(method + "_" + env_names) and file.endswith(".pth"):
        model_path = file
udim = 3
Nstates = 6
dicts = torch.load(root_path+"/"+model_path,map_location=torch.device('cpu'))
state_dict = dicts["model"]
layer = dicts["layer"]
NKoopman =layer[-1]+Nstates
netw = lkw.Network(layer,NKoopman,udim)
netw.load_state_dict(state_dict)
netw.cuda()
netw.double()
#提取A,B
Alift=netw.lA.weight.data.cpu().numpy()
Blift=netw.lB.weight.data.cpu().numpy()

#2 加载升维函数
def getlift(q):
    q=q.reshape(1, -1)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    q= torch.DoubleTensor(q).to(device)
    q_current = netw.encode(q)
    q_current = q_current.detach().cpu().numpy().T
    return q_current

#3 定义动力学 为了得到真实数据
def dynamics(y, t, INPUT):
    I = np.diag([3, 4, 5])
    theta = y[0:3].reshape(-1, 1)
    afa = theta[0].item()
    beta = theta[1].item()
    R = np.asarray([[-np.tan(beta) * np.cos(afa), 1, -np.tan(beta) * np.sin(afa)], [np.sin(afa), 0, -np.cos(afa)],
                    [-np.cos(beta) * np.cos(afa), -np.sin(beta), -np.cos(beta) * np.sin(afa)]])
    w = y[3:].reshape(-1, 1)
    thetadot = R @ w
    inv_I = np.linalg.inv(I)
    wdot = np.dot(inv_I, -hat(w) @ (I @ w) + INPUT.reshape(-1, 1))

    # state=np.concatenate((qdot1,qdot2,wdot),axis=0)
    return [thetadot[0].item(), thetadot[1].item(), thetadot[2].item(), wdot[0].item(), wdot[1].item(),
            wdot[2].item()]


#3 定义MPC框架
#z0，zr，A,B,wr，N
def MPCcost(z_init,zr,A_bar,B_bar,w_r,N,Q,R,Q_N,x_min, x_max, u_min, u_max):
    u = Variable((3, N))
    x = Variable((len(z_init), N + 1))
    objective = 0
    constraints = [x[:, 0] == z_init]
    for i in range(N):
        constraints += [x[:, i + 1] == A_bar @ x[:, i] + B_bar @ (u[:,i])]
        # constraints += [x_min <= x[3:6, i], x[3:6, i] <= x_max]  # 状态约束
        constraints += [u_min <= u[:, i], u[:, i] <= u_max]  # 控制约束
        objective += quad_form(x[:,i], Q) + quad_form(u[:,i], R)
    objective += quad_form(x[:,N], Q_N)
    # constraints += [x_min <= x[:, N], x[:, N] <= x_max]  # 最终状态约束
    prob = Problem(Minimize(objective), constraints)
    prob.solve()
    u_m = u[:,0].value
    return u_m

#4 初始姿态与目标姿态 x0与xd
R_0=np.array([[0.4830, 0.8365,  0.2588],
                [-0.3209, 0.4441, -0.8365],
                [-0.8147, 0.3209, 0.4830]])

R_d=np.array([[1, 0,  1],
                [0, 1, 0],
                [0, 0, 1]])
theta_0=rot2euler(R_0)
theta_0=np.random.uniform(-1,1, (3,1))*(np.pi/4)
# theta_d=rot2euler(R_d)
theta_d=np.random.uniform(-1,1, (3,1))*(np.pi/4) * 0
w_0= np.random.uniform(-1, 1, (3,)) * 0
w_d= np.random.uniform(-1, 1, (3,)) * 0

x_0 = np.vstack((theta_0.reshape(-1, 1), w_0.reshape(-1, 1))).reshape(-1, )
x_d = np.vstack((theta_d.reshape(-1, 1), w_d.reshape(-1, 1))).reshape(-1, )

#5状态方程, 升维后的状态
Alift=Alift
Blift=Blift
z_0=getlift(x_0)
z_d=getlift(x_d)
ze_0=z_0-z_d
#w_r为误差，不是角速度
w_r=z_d-Alift@z_d #z_r=Az_r+w_r
#定义Q,R,k
nq=len(Alift)
Q=np.zeros((nq,nq))

Q[:6,:6]=np.eye(6)*100#q的权重
R=np.eye(3)
k=dlqr(np.matrix(Alift),np.matrix(Blift),Q,R)
x_min, x_max, u_min, u_max=0,0,0,0

#6 仿真
nsim=300
N=8
dt=0.1
Xcurrent=x_0

#koopmandata
Koopmandata = np.zeros((6, nsim + 1))
Koopmandata[:, 0] = Xcurrent.reshape(-1, )
#真实数据
Turedata = np.zeros((6, nsim + 1))
Turedata[:, 0] = Xcurrent.reshape(-1, )
Controldata = np.zeros((3, nsim))
z_k=z_0
z=z_0
u_max=np.asarray([0.5,0.5,0.5])
u_min=-1*u_max

x_max=np.asarray([0.15,0.15,0.15])
x_min=-1*u_max
for i in range(nsim):
    print(i)
    u_m=MPCcost(ze_0.reshape(-1,),z_d.reshape(-1,),Alift,Blift,w_r.reshape(-1,),N,Q,R,Q,x_min, x_max, u_min, u_max)
    u_m=np.asarray(u_m).reshape(-1,)
    # 控制量
    # dz = getlift(Xcurrent) - z_d
    # u = - (k @ dz).reshape(-1, )
    dz=getlift(Xcurrent)-(ze_0+z_d)
    u=u_m.reshape(-1,)-(k@dz).reshape(-1,)
    u=np.asarray(u).reshape(-1,)

    # Rmpc 更新
    ze_0=Alift@ze_0.reshape(-1,)+Blift@u_m #Rmpc
    ze_0=ze_0.reshape(-1,1)

    Koopmandata[:, i + 1]=ze_0[:6].reshape(-1,)
    # 真实系统更新
    sn = odeint(dynamics, Xcurrent, [0, dt], args=(u,))
    Xcurrent = sn[-1, :]
    Turedata[:, i + 1] = Xcurrent.reshape(-1, )
    # z_0 = getlift(Xcurrent)
    Controldata[:, i]= u_m.reshape(-1, )

for i in range(6):
    plt.plot(Turedata[i, :], color='red')
    plt.plot(Koopmandata[i, :], color='blue')
    # plt.axhline(x_d[i],color='red')
    plt.show()

# for i in range(3):
#     plt.plot(Controldata[i, :], color='blue')
#     plt.axhline(0,color='red')
#     plt.axhline(0, color='red')
#     plt.show()
